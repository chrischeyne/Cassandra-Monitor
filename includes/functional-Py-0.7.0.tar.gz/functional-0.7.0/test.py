import tests
import tests.support

tests.support.run_all_tests(tests=tests.all_tests)
